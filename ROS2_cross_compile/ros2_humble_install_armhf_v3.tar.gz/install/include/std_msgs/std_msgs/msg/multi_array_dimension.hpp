// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef STD_MSGS__MSG__MULTI_ARRAY_DIMENSION_HPP_
#define STD_MSGS__MSG__MULTI_ARRAY_DIMENSION_HPP_

#include "std_msgs/msg/detail/multi_array_dimension__struct.hpp"
#include "std_msgs/msg/detail/multi_array_dimension__builder.hpp"
#include "std_msgs/msg/detail/multi_array_dimension__traits.hpp"

#endif  // STD_MSGS__MSG__MULTI_ARRAY_DIMENSION_HPP_
