// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef PENDULUM_MSGS__MSG__JOINT_COMMAND_HPP_
#define PENDULUM_MSGS__MSG__JOINT_COMMAND_HPP_

#include "pendulum_msgs/msg/detail/joint_command__struct.hpp"
#include "pendulum_msgs/msg/detail/joint_command__builder.hpp"
#include "pendulum_msgs/msg/detail/joint_command__traits.hpp"

#endif  // PENDULUM_MSGS__MSG__JOINT_COMMAND_HPP_
