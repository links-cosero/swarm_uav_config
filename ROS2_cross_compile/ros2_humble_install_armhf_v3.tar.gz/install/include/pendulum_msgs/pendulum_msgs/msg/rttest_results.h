// generated from rosidl_generator_c/resource/idl.h.em
// with input from pendulum_msgs:msg/RttestResults.idl
// generated code does not contain a copyright notice

#ifndef PENDULUM_MSGS__MSG__RTTEST_RESULTS_H_
#define PENDULUM_MSGS__MSG__RTTEST_RESULTS_H_

#include "pendulum_msgs/msg/detail/rttest_results__struct.h"
#include "pendulum_msgs/msg/detail/rttest_results__functions.h"
#include "pendulum_msgs/msg/detail/rttest_results__type_support.h"

#endif  // PENDULUM_MSGS__MSG__RTTEST_RESULTS_H_
