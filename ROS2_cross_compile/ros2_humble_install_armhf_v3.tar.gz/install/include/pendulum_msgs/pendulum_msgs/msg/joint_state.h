// generated from rosidl_generator_c/resource/idl.h.em
// with input from pendulum_msgs:msg/JointState.idl
// generated code does not contain a copyright notice

#ifndef PENDULUM_MSGS__MSG__JOINT_STATE_H_
#define PENDULUM_MSGS__MSG__JOINT_STATE_H_

#include "pendulum_msgs/msg/detail/joint_state__struct.h"
#include "pendulum_msgs/msg/detail/joint_state__functions.h"
#include "pendulum_msgs/msg/detail/joint_state__type_support.h"

#endif  // PENDULUM_MSGS__MSG__JOINT_STATE_H_
